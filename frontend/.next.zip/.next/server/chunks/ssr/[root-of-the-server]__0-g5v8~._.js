module.exports=[50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},64254,a=>{"use strict";let b=(0,a.i(92277).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);a.s(["Calendar",0,b],64254)},93926,a=>{"use strict";let b=process.env.API_URL||"https://api.mistosyly.org";a.s(["fetchLive",0,function(a,c){let d;return fetch((d=a.startsWith("/")?a:`/${a}`,`${b}${d}`),{...c,cache:"no-store"})}])},39138,a=>{"use strict";a.s(["fixMediaUrls",0,function(a){return a.replace(/src="\/media\//g,'src="https://api.mistosyly.org/media/')}])},10585,a=>{a.v("/_next/static/media/favicon.0s7a~2j35nq2y.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},68611,a=>{"use strict";let b={src:a.i(10585).default,width:532,height:490};a.s(["default",0,b])},72958,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/ContentRenderer.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/ContentRenderer.tsx <module evaluation>","default")},17333,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/ContentRenderer.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/ContentRenderer.tsx","default")},85533,a=>{"use strict";a.i(72958);var b=a.i(17333);a.n(b)},18810,a=>{"use strict";var b=a.i(7997);a.i(70396);var c=a.i(73727),d=a.i(3236),e=a.i(95936),f=a.i(64254),g=a.i(84930),h=a.i(93926),i=a.i(39138),j=a.i(85533);async function k(a){try{let b=await (0,h.fetchLive)(`/api/v1/reports/${a}/`);if(!b.ok)return null;return b.json()}catch{return null}}async function l({params:a}){let{slug:b}=await a,c=await k(b);return c?{title:c.title,openGraph:{title:c.title,images:c.image?[c.image]:[]}}:{title:"Звіт не знайдено"}}function m(a){return new Date(a).toLocaleDateString("uk-UA",{day:"numeric",month:"long",year:"numeric"})}async function n({params:a}){let{slug:h}=await a,l=await k(h);return l||(0,c.notFound)(),(0,b.jsxs)("article",{children:[(0,b.jsx)("style",{children:`
        .report-content {
          font-family: var(--font-main);
          font-size: 1rem;
          line-height: 1.7;
          color: var(--charcoal);
          width: 100%;
        }
        .report-content h1 {
          font-size: clamp(1.5rem, 3vw, 2.25rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 2rem 0 1rem;
        }
        .report-content h2 {
          font-size: clamp(1.25rem, 2.5vw, 1.75rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 2rem 0 1rem;
        }
        .report-content h3 {
          font-size: clamp(1.1rem, 2vw, 1.375rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.5rem 0 0.75rem;
        }
        .report-content p {
          font-size: 1rem;
          margin-bottom: 1rem;
        }
        .report-content ul, .report-content ol {
          font-size: 1rem;
          padding-left: 1.5rem;
          margin-bottom: 1rem;
        }
        .report-content li {
          margin-bottom: 0.4rem;
        }
        .report-content figure.table {
          margin: 1.5rem auto;
          display: flex;
          justify-content: center;
          width: 100%;
        }
        .report-content figure.table table {
          border-collapse: collapse;
          width: auto;
          font-size: 0.9rem;
        }
        .report-content td, .report-content th {
          border: 1px solid var(--border);
          padding: 0.6rem 0.9rem;
          text-align: left;
        }
        .report-content th {
          background: var(--off-white);
          font-weight: 700;
        }
        .report-content a {
          color: var(--teal);
          text-decoration: underline;
          font-size: 1rem;
        }
        .report-content figure {
          margin: 1.5rem auto;
          text-align: center;
          display: block;
          width: 100%;
        }
        .report-content figure img {
          margin: 0 auto;
          display: block;
        }
        .report-content img {
          max-width: 100%;
          height: auto;
          margin: 1.5rem auto;
          display: block;
          box-shadow: 0 4px 20px rgba(0,0,0,0.1);
          cursor: zoom-in;
          transition: opacity 0.2s;
          /* Примусово забираємо обмеження розміру від редактора */
          width: auto !important;
          max-width: 100% !important;
        }
        .report-content img:hover {
          opacity: 0.9;
        }
        .report-content figcaption {
          font-size: 0.9rem;
          color: var(--charcoal);
          margin-top: 0.5rem;
          font-style: italic;
        }
        .report-content .image-style-align-left {
          float: left;
          margin: 0 1.5rem 1rem 0;
          max-width: 45%;
        }
        .report-content .image-style-align-left img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .report-content .image-style-align-right {
          float: right;
          margin: 0 0 1rem 1.5rem;
          max-width: 45%;
        }
        .report-content .image-style-align-right img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .report-content .image-style-align-center {
          margin: 1.5rem auto;
          display: block;
          max-width: 100%;
        }
        .report-content .image-style-align-center img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .report-content::after {
          content: '';
          display: table;
          clear: both;
        }
        .report-content blockquote {
          border-left: 4px solid var(--teal);
          padding: 0.8rem 1.2rem;
          margin: 1.2rem 0;
          background: var(--off-white);
          font-style: italic;
          font-size: 1rem;
        }
        /* Мобільна адаптація */
        @media (max-width: 640px) {
          .report-content {
            font-size: 0.95rem;
          }
          .report-content p {
            font-size: 0.95rem;
          }
          .report-content ul, .report-content ol {
            font-size: 0.95rem;
          }
          .report-content .image-style-align-left,
          .report-content .image-style-align-right {
            float: none;
            max-width: 100% !important;
            margin: 1rem auto;
            display: block;
          }
          .report-content .image-style-align-left img,
          .report-content .image-style-align-right img,
          .report-content .image-style-align-center img,
          .report-content img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 1rem auto;
          }
          /* Додатково перезаписуємо будь-які inline стилі */
          .report-content figure img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
          }
          .report-content figure {
            width: 100% !important;
            max-width: 100% !important;
          }
          .report-content figure.table {
            overflow-x: auto;
            justify-content: flex-start;
          }
          .report-content figure.table table {
            width: 100%;
            font-size: 0.8rem;
          }
          .report-content figure.table td,
          .report-content figure.table th {
            padding: 0.4rem 0.6rem;
            white-space: nowrap;
          }
          .report-content blockquote {
            font-size: 0.95rem;
            padding: 0.6rem 1rem;
          }
          .report-content figcaption {
            font-size: 0.85rem;
          }
        }
      `}),l.image&&(0,b.jsxs)("div",{style:{position:"relative",width:"100%",height:"clamp(240px, 40vw, 480px)",overflow:"hidden",background:"var(--charcoal-dark)"},children:[(0,b.jsx)(d.default,{src:l.image,alt:l.title,fill:!0,sizes:"100vw",style:{objectFit:"cover",opacity:.85},loading:"eager",priority:!0}),(0,b.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to bottom, transparent 40%, rgba(30,30,30,0.8) 100%)"}}),(0,b.jsxs)("div",{className:"container",style:{position:"absolute",bottom:0,left:0,right:0,padding:"2rem 1.5rem"},children:[l.date_published&&(0,b.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.75rem"},children:[(0,b.jsx)(f.Calendar,{size:15,style:{color:"var(--teal-light)"}}),(0,b.jsx)("time",{dateTime:l.date_published,style:{fontSize:"0.9rem",color:"var(--teal-light)",fontWeight:500,textTransform:"uppercase",letterSpacing:"0.05em"},children:m(l.date_published)})]}),(0,b.jsx)("h1",{style:{fontSize:"clamp(1.5rem, 4vw, 3rem)",fontWeight:700,color:"#fff",lineHeight:1.2},children:l.title})]})]}),(0,b.jsxs)("div",{className:"container",style:{padding:"3rem 1.5rem"},children:[!l.image&&(0,b.jsxs)("header",{style:{marginBottom:"2.5rem"},children:[l.date_published&&(0,b.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.75rem"},children:[(0,b.jsx)(f.Calendar,{size:15,style:{color:"var(--teal)"}}),(0,b.jsx)("time",{dateTime:l.date_published,style:{fontSize:"0.9rem",color:"var(--teal)",fontWeight:500,textTransform:"uppercase",letterSpacing:"0.05em"},children:m(l.date_published)})]}),(0,b.jsx)("h1",{style:{fontSize:"clamp(1.75rem, 4vw, 3rem)",fontWeight:700,color:"var(--charcoal-dark)"},children:l.title})]}),(0,b.jsx)(j.default,{html:(0,i.fixMediaUrls)(l.content),className:"report-content",style:{width:"100%"}}),(0,b.jsx)("div",{style:{marginTop:"3rem",paddingTop:"2rem",borderTop:"1px solid var(--border)"},children:(0,b.jsxs)(e.default,{href:"/reports",className:"btn-outline",style:{display:"inline-flex",alignItems:"center",gap:"0.5rem"},children:[(0,b.jsx)(g.ArrowLeft,{size:16}),"Усі звіти"]})})]})]})}a.s(["default",0,n,"dynamic",0,"force-dynamic","generateMetadata",0,l])},66602,a=>{a.n(a.i(18810))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0-g5v8~._.js.map