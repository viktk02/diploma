module.exports=[50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},64254,a=>{"use strict";let b=(0,a.i(92277).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);a.s(["Calendar",0,b],64254)},93926,a=>{"use strict";let b=process.env.API_URL||"https://api.mistosyly.org";a.s(["fetchLive",0,function(a,c){let d;return fetch((d=a.startsWith("/")?a:`/${a}`,`${b}${d}`),{...c,cache:"no-store"})}])},10585,a=>{a.v("/_next/static/media/favicon.0s7a~2j35nq2y.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},68611,a=>{"use strict";let b={src:a.i(10585).default,width:532,height:490};a.s(["default",0,b])},44403,a=>{"use strict";var b=a.i(7997);a.i(70396);var c=a.i(73727),d=a.i(3236),e=a.i(95936),f=a.i(64254),g=a.i(81005),h=a.i(84930);let i=(0,a.i(92277).default)("clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]]);var j=a.i(93926);async function k(a){try{let b=await (0,j.fetchLive)(`/api/v1/events/${a}/`);if(!b.ok)return null;return b.json()}catch{return null}}async function l({params:a}){let{slug:b}=await a,c=await k(b);return c?{title:c.title,description:c.description.slice(0,160),openGraph:{title:c.title,images:c.image?[c.image]:[]}}:{title:"Подію не знайдено"}}async function m({params:a}){let j,{slug:l}=await a,n=await k(l);n||(0,c.notFound)();let o={full:(j=new Date(n.date)).toLocaleDateString("uk-UA",{day:"numeric",month:"long",year:"numeric"}),time:j.toLocaleTimeString("uk-UA",{hour:"2-digit",minute:"2-digit"}),isPast:j<new Date};return(0,b.jsxs)("article",{children:[(0,b.jsx)("style",{children:`
        .event-grid {
          display: grid;
          grid-template-columns: 1fr 300px;
          gap: 3rem;
          align-items: start;
          padding: 4rem 0;
        }
        .event-description { order: 1; }
        .event-aside {
          order: 2;
          background: var(--off-white);
          padding: 2rem;
          border-left: 4px solid var(--teal);
        }
        
        /* Покращене вирівнювання для деталей події */
        .event-detail-item {
          display: flex;
          align-items: flex-start;
          gap: 0.75rem;
        }
        .event-detail-item .icon-wrapper {
          flex-shrink: 0;
          width: 20px;
          padding-top: 0.15rem;
        }
        .event-detail-item .detail-content {
          display: flex;
          flex-direction: column;
          gap: 0.1rem;
          flex: 1;
          min-width: 0;
        }
        .event-detail-item .detail-label {
          font-size: 0.7rem;
          font-weight: 700;
          color: var(--charcoal);
          text-transform: uppercase;
          letter-spacing: 0.08em;
          line-height: 1.2;
        }
        .event-detail-item .detail-value {
          font-size: 1rem;
          font-weight: 600;
          color: var(--charcoal-dark);
          line-height: 1.3;
          word-break: break-word;
        }
        
        @media (max-width: 768px) {
          .event-grid {
            grid-template-columns: 1fr;
            gap: 2rem;
            padding: 2rem 0;
          }
          .event-description { order: 2; }
          .event-aside {
            order: 1;
            border-left: none;
            border-top: 4px solid var(--teal);
          }
        }
      `}),(0,b.jsxs)("div",{style:{position:"relative",width:"100%",height:"clamp(280px, 40vw, 480px)",overflow:"hidden",background:"var(--charcoal-dark)"},children:[n.image?(0,b.jsx)(d.default,{src:n.image,alt:n.title,fill:!0,sizes:"100vw",style:{objectFit:"cover",opacity:.8},priority:!0}):(0,b.jsx)("div",{style:{width:"100%",height:"100%",background:"linear-gradient(135deg, var(--teal-dark), var(--charcoal-dark))"}}),(0,b.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to bottom, transparent 30%, rgba(20,20,20,0.85) 100%)"}}),(0,b.jsxs)("div",{className:"container",style:{position:"absolute",bottom:0,left:0,right:0,padding:"2.5rem 1.5rem"},children:[(0,b.jsx)("span",{style:{display:"inline-block",padding:"0.25rem 0.875rem",background:o.isPast?"var(--charcoal)":"var(--teal)",color:"#fff",fontSize:"1rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"1rem"},children:o.isPast?"Завершено":"Майбутня подія"}),(0,b.jsx)("h1",{style:{fontSize:"clamp(1.75rem, 4vw, 3rem)",fontWeight:700,color:"#fff",lineHeight:1.2,maxWidth:"800px"},children:n.title})]})]}),(0,b.jsx)("div",{className:"container",children:(0,b.jsxs)("div",{className:"event-grid",children:[(0,b.jsxs)("div",{className:"event-description",children:[(0,b.jsx)("p",{style:{fontSize:"1.125rem",lineHeight:1.8,color:"var(--charcoal)",whiteSpace:"pre-line"},children:n.description}),(0,b.jsx)("div",{style:{marginTop:"3rem",paddingTop:"2rem",borderTop:"1px solid var(--border)"},children:(0,b.jsxs)(e.default,{href:"/events",className:"btn-outline",style:{display:"inline-flex",alignItems:"center",gap:"0.5rem"},children:[(0,b.jsx)(h.ArrowLeft,{size:16}),"Усі події"]})})]}),(0,b.jsxs)("aside",{className:"event-aside event-aside--mobile-center",children:[(0,b.jsx)("h2",{style:{fontSize:"1rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",color:"var(--teal)",marginBottom:"1.5rem"},children:"Деталі події"}),(0,b.jsxs)("ul",{style:{listStyle:"none",display:"flex",flexDirection:"column",gap:"1.25rem",margin:0,padding:0},children:[(0,b.jsxs)("li",{className:"event-detail-item",children:[(0,b.jsx)("div",{className:"icon-wrapper",children:(0,b.jsx)(f.Calendar,{size:18,style:{color:"var(--teal)"}})}),(0,b.jsxs)("div",{className:"detail-content",children:[(0,b.jsx)("span",{className:"detail-label",children:"Дата"}),(0,b.jsx)("time",{dateTime:n.date,className:"detail-value",children:o.full})]})]}),(0,b.jsxs)("li",{className:"event-detail-item",children:[(0,b.jsx)("div",{className:"icon-wrapper",children:(0,b.jsx)(i,{size:18,style:{color:"var(--teal)"}})}),(0,b.jsxs)("div",{className:"detail-content",children:[(0,b.jsx)("span",{className:"detail-label",children:"Час"}),(0,b.jsx)("span",{className:"detail-value",children:o.time})]})]}),n.location&&(0,b.jsxs)("li",{className:"event-detail-item",children:[(0,b.jsx)("div",{className:"icon-wrapper",children:(0,b.jsx)(g.MapPin,{size:18,style:{color:"var(--teal)"}})}),(0,b.jsxs)("div",{className:"detail-content",children:[(0,b.jsx)("span",{className:"detail-label",children:"Місце"}),(0,b.jsx)("span",{className:"detail-value",children:n.location})]})]})]})]})]})})]})}a.s(["default",0,m,"dynamic",0,"force-dynamic","generateMetadata",0,l],44403)},52943,a=>{a.n(a.i(44403))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0m3yp-b._.js.map