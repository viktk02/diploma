module.exports=[16561,a=>{"use strict";var b=a.i(87924),c=a.i(72131);a.s(["default",0,({html:a,className:d,style:e})=>{let f=(0,c.useRef)(null);(0,c.useEffect)(()=>{if(!f.current)return;let b=a||"";b=(b=b.replace(/<figure class="media">\s*<oembed url="([^"]+)"\s*\/?>\s*<\/oembed>\s*<\/figure>/gi,(a,b)=>g(b))).replace(/<oembed url="([^"]+)"\s*\/?>\s*<\/oembed>/gi,(a,b)=>g(b)),f.current.innerHTML=b,h()},[a]);let g=a=>{if(a.includes("youtube.com")||a.includes("youtu.be")){let b="";if(a.includes("youtu.be/")?b=a.split("youtu.be/")[1].split("?")[0]:a.includes("v=")?b=a.split("v=")[1].split("&")[0]:a.includes("embed/")&&(b=a.split("embed/")[1].split("?")[0]),b)return`
          <div class="video-container">
            <iframe
              src="https://www.youtube.com/embed/${b}"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
              loading="lazy"
            ></iframe>
          </div>
        `}if(a.includes("vimeo.com")){let b=a.split("/").pop()?.split("?")[0]||"";if(b)return`
          <div class="video-container">
            <iframe
              src="https://player.vimeo.com/video/${b}"
              frameborder="0"
              allow="autoplay; fullscreen; picture-in-picture"
              allowfullscreen
              loading="lazy"
            ></iframe>
          </div>
        `}return`<a href="${a}" target="_blank" rel="noopener noreferrer">${a}</a>`},h=()=>{if(document.getElementById("video-styles"))return;let a=document.createElement("style");a.id="video-styles",a.textContent=`
      .video-container {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        margin: 1.5rem 0;
        border-radius: 8px;
        overflow: hidden;
        background: #000;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      }
      .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
      }
    `,document.head.appendChild(a)};return(0,b.jsx)("div",{ref:f,className:d,style:e})}])}];

//# sourceMappingURL=src_components_ContentRenderer_tsx_09w3djd._.js.map