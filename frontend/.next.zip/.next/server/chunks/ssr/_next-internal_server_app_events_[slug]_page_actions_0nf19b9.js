module.exports=[45274,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_%5Bslug%5D_page_actions_0nf19b9.js.map