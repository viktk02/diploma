module.exports=[47900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Bkey%5D_page_actions_0oxig21.js.map