module.exports=[50640,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},64254,a=>{"use strict";let b=(0,a.i(92277).default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);a.s(["Calendar",0,b],64254)},23351,a=>{"use strict";let b=(0,a.i(92277).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);a.s(["ArrowRight",0,b],23351)},39138,a=>{"use strict";a.s(["fixMediaUrls",0,function(a){return a.replace(/src="\/media\//g,'src="https://api.mistosyly.org/media/')}])},84751,a=>{"use strict";a.s(["GallerySectionClient",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call GallerySectionClient() from the server but GallerySectionClient is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/GallerySection.tsx <module evaluation>","GallerySectionClient")},44237,a=>{"use strict";a.s(["GallerySectionClient",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call GallerySectionClient() from the server but GallerySectionClient is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/GallerySection.tsx","GallerySectionClient")},13479,a=>{"use strict";a.i(84751);var b=a.i(44237);a.n(b)},96270,a=>{"use strict";var b=a.i(7997),c=a.i(3236),d=a.i(95936),e=a.i(13479),f=a.i(23351),g=a.i(39138);function h({section:a}){return(0,b.jsxs)("section",{style:{background:"linear-gradient(135deg, var(--charcoal-dark) 0%, #2a2a2a 60%, var(--teal-dark) 100%)",color:"#fff",padding:"clamp(3rem, 8vw, 6rem) 0",position:"relative",overflow:"hidden"},children:[a.image&&(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(c.default,{src:(0,g.fixMediaUrls)(a.image),alt:a.image_alt||a.title,fill:!0,style:{objectFit:"cover",opacity:.3},sizes:"100vw",loading:"eager",priority:!0}),(0,b.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(135deg, rgba(30,30,30,0.9), rgba(78,153,128,0.6))"}})]}),(0,b.jsx)("div",{className:"container",style:{position:"relative",zIndex:1},children:(0,b.jsxs)("div",{style:{maxWidth:"700px"},children:[a.subtitle&&(0,b.jsx)("span",{style:{display:"inline-block",background:"var(--teal)",color:"#fff",padding:"0.375rem 1rem",fontSize:"0.9rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:"1.5rem"},children:a.subtitle}),a.title&&(0,b.jsx)("h1",{style:{fontSize:"clamp(2.2rem, 5.2vw, 4.4rem)",fontWeight:700,lineHeight:1.1,marginBottom:"1.5rem",color:"#fff"},children:a.title}),a.content&&(0,b.jsx)("div",{style:{fontSize:"clamp(0.95rem, 1.5vw, 1.1rem)",color:"rgba(255,255,255,0.85)",lineHeight:1.7,marginBottom:"2.5rem"},dangerouslySetInnerHTML:{__html:(0,g.fixMediaUrls)(a.content)}}),a.button_text&&a.button_url&&(0,b.jsxs)(d.default,{href:a.button_url,className:"btn-primary",children:[a.button_text," ",(0,b.jsx)(f.ArrowRight,{size:16})]})]})})]})}function i({section:a,isAboveFold:e=!1}){let h=!!a.image;return(0,b.jsx)("section",{className:"section",style:{padding:"clamp(2.5rem, 5vw, 4rem) 0"},children:(0,b.jsx)("div",{className:"container",children:(0,b.jsxs)("div",{style:{display:"grid",gridTemplateColumns:h?"1fr 1fr":"1fr",gap:"3rem",alignItems:"center"},children:[(0,b.jsxs)("div",{style:{maxWidth:h?"100%":"800px"},children:[a.title&&(0,b.jsx)("h2",{className:"section-title",children:a.title}),a.subtitle&&(0,b.jsx)("p",{style:{fontSize:"1rem",color:"var(--teal)",fontWeight:500,marginBottom:"1rem"},children:a.subtitle}),a.content&&(0,b.jsx)("div",{className:"cms-content",dangerouslySetInnerHTML:{__html:(0,g.fixMediaUrls)(a.content)}}),a.button_text&&a.button_url&&(0,b.jsx)("div",{style:{marginTop:"1.5rem"},children:(0,b.jsxs)(d.default,{href:a.button_url,className:"btn-primary",children:[a.button_text," ",(0,b.jsx)(f.ArrowRight,{size:16})]})})]}),h&&(0,b.jsx)("div",{style:{position:"relative",height:"clamp(280px, 40vw, 480px)",overflow:"hidden"},children:(0,b.jsx)(c.default,{src:(0,g.fixMediaUrls)(a.image),alt:a.image_alt||a.title,fill:!0,style:{objectFit:"cover"},loading:e?"eager":"lazy",priority:e})})]})})})}function j({section:a}){return(0,b.jsx)("section",{style:{background:"var(--teal)",padding:"clamp(3rem, 6vw, 4.5rem) 0"},children:(0,b.jsxs)("div",{className:"container",style:{textAlign:"center"},children:[a.title&&(0,b.jsx)("h2",{style:{fontSize:"clamp(1.75rem, 3.4vw, 2.6rem)",fontWeight:700,color:"#fff",marginBottom:"0.75rem"},children:a.title}),a.subtitle&&(0,b.jsx)("p",{style:{fontSize:"1rem",color:"rgba(255,255,255,0.85)",marginBottom:"1.5rem"},children:a.subtitle}),a.content&&(0,b.jsx)("div",{style:{color:"rgba(255,255,255,0.85)",fontSize:"0.95rem",marginBottom:"1.5rem"},dangerouslySetInnerHTML:{__html:(0,g.fixMediaUrls)(a.content)}}),a.button_text&&a.button_url&&(0,b.jsxs)(d.default,{href:a.button_url,style:{display:"inline-flex",alignItems:"center",gap:"0.5rem",padding:"1rem 2.5rem",background:"#fff",color:"var(--teal)",fontFamily:"var(--font-main)",fontSize:"0.95rem",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.05em",textDecoration:"none",transition:"all 0.2s"},children:[a.button_text," ",(0,b.jsx)(f.ArrowRight,{size:16})]})]})})}function k({section:a}){return(0,b.jsx)("section",{className:"section",style:{background:"var(--off-white)",padding:"clamp(2.5rem, 5vw, 4rem) 0"},children:(0,b.jsxs)("div",{className:"container",style:{textAlign:"center"},children:[a.title&&(0,b.jsx)("h2",{className:"section-title centered",children:a.title}),a.content&&(0,b.jsx)("div",{className:"cms-content",style:{maxWidth:"600px",margin:"0 auto 1.5rem"},dangerouslySetInnerHTML:{__html:(0,g.fixMediaUrls)(a.content)}}),(0,b.jsxs)(d.default,{href:"/contacts",className:"btn-primary",children:["Зв'язатися з нами ",(0,b.jsx)(f.ArrowRight,{size:16})]})]})})}a.s(["PageRenderer",0,function({sections:a}){let c=[...a].filter(a=>a).sort((a,b)=>a.order-b.order);return(0,b.jsxs)(b.Fragment,{children:[c.map((a,c)=>(function(a,c=0){switch(a.section_type){case"hero":return(0,b.jsx)(h,{section:a},a.id);case"text":return(0,b.jsx)(i,{section:a,isAboveFold:0===c},a.id);case"gallery":return(0,b.jsx)(e.GallerySectionClient,{images:a.images,title:a.title,subtitle:a.subtitle},a.id);case"cta":return(0,b.jsx)(j,{section:a},a.id);case"contacts":return(0,b.jsx)(k,{section:a},a.id);default:return null}})(a,c)),(0,b.jsx)("style",{children:`
        .cms-content {
          font-family: var(--font-main);
          font-size: 0.95rem;
          line-height: 1.7;
          color: var(--charcoal);
        }
        /* H1 в контенті - менший за глобальний h1 */
        .cms-content h1 {
          font-size: clamp(1.5rem, 3vw, 2.4rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.5rem 0 0.75rem;
        }
        /* H2 в контенті - менший за глобальний h2 */
        .cms-content h2 {
          font-size: clamp(1.3rem, 2.6vw, 1.95rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.25rem 0 0.75rem;
        }
        /* H3 в контенті - менший за глобальний h3 */
        .cms-content h3 {
          font-size: clamp(1.05rem, 1.9vw, 1.35rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1rem 0 0.5rem;
        }
        /* H4 в контенті - менший за глобальний h4 */
        .cms-content h4 {
          font-size: clamp(0.95rem, 1.6vw, 1.15rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.75rem 0 0.5rem;
        }
        .cms-content h5, .cms-content h6 {
          font-size: clamp(0.9rem, 1.4vw, 1rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.5rem 0 0.5rem;
        }
        .cms-content p {
          font-size: 0.95rem;
          margin-bottom: 0.75rem;
        }
        .cms-content ul, .cms-content ol {
          font-size: 0.95rem;
          padding-left: 1.5rem;
          margin-bottom: 0.75rem;
        }
        .cms-content li {
          margin-bottom: 0.3rem;
        }
        .cms-content a {
          color: var(--teal);
          font-size: 0.95rem;
        }
        .cms-content img {
          max-width: 100%;
          height: auto;
          margin: 1.25rem auto;
          display: block;
          box-shadow: 0 4px 20px rgba(0,0,0,0.1);
          cursor: zoom-in;
          width: auto !important;
          max-width: 100% !important;
        }
        .cms-content figure {
          margin: 1.25rem 0;
          text-align: center;
        }
        .cms-content figcaption {
          font-size: 0.9rem;
          color: var(--charcoal);
          margin-top: 0.4rem;
          font-style: italic;
        }
        .cms-content .image-style-align-left {
          float: left;
          margin: 0 1.5rem 0.75rem 0;
          max-width: 45%;
        }
        .cms-content .image-style-align-left img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-right {
          float: right;
          margin: 0 0 0.75rem 1.5rem;
          max-width: 45%;
        }
        .cms-content .image-style-align-right img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-center {
          margin: 1.25rem auto;
          display: block;
          max-width: 100%;
        }
        .cms-content .image-style-align-center img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content::after {
          content: '';
          display: table;
          clear: both;
        }
        .cms-content blockquote {
          border-left: 4px solid var(--teal);
          padding: 0.6rem 1.2rem;
          margin: 1rem 0;
          background: var(--off-white);
          font-style: italic;
          font-size: 0.95rem;
        }
        .cms-content table {
          border-collapse: collapse;
          width: 100%;
          font-size: 0.85rem;
          margin: 1.25rem 0;
        }
        .cms-content td, .cms-content th {
          border: 1px solid var(--border);
          padding: 0.5rem 0.8rem;
          text-align: left;
        }
        .cms-content th {
          background: var(--off-white);
          font-weight: 700;
        }

        /* Зменшені відступи для .section-title */
        .section-title {
          margin-bottom: 2rem;
        }
        .section-title::after {
          margin-top: 0.75rem;
        }
        .section-title.centered::after {
          margin: 0.75rem auto 0;
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns: 1fr 1fr"] {
            grid-template-columns: 1fr !important;
          }
          .cms-content {
            font-size: 0.9rem;
          }
          .cms-content h1 {
            font-size: clamp(1.35rem, 4.5vw, 1.8rem);
          }
          .cms-content h2 {
            font-size: clamp(1.2rem, 3.5vw, 1.6rem);
          }
          .cms-content h3 {
            font-size: clamp(1rem, 2.8vw, 1.2rem);
          }
          .cms-content p {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content ul, .cms-content ol {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content .image-style-align-left,
          .cms-content .image-style-align-right {
            float: none;
            max-width: 100% !important;
            margin: 0.75rem auto;
            display: block;
          }
          .cms-content .image-style-align-left img,
          .cms-content .image-style-align-right img,
          .cms-content .image-style-align-center img,
          .cms-content img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 0.75rem auto;
          }
          .cms-content figure img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
          }
          .cms-content figure {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0.75rem 0;
          }
          .cms-content table {
            font-size: 0.8rem;
            display: block;
            overflow-x: auto;
            white-space: nowrap;
            margin: 0.75rem 0;
          }
          .cms-content td, .cms-content th {
            padding: 0.3rem 0.5rem;
          }
          .cms-content blockquote {
            font-size: 0.9rem;
            padding: 0.5rem 0.8rem;
            margin: 0.75rem 0;
          }
          .cms-content figcaption {
            font-size: 0.8rem;
            margin-top: 0.3rem;
          }
          .section-title {
            margin-bottom: 1.5rem;
          }
          .section-title::after {
            margin-top: 0.5rem;
            width: 3rem;
          }
        }
      `})]})}])},10585,a=>{a.v("/_next/static/media/favicon.0s7a~2j35nq2y.ico"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},68611,a=>{"use strict";let b={src:a.i(10585).default,width:532,height:490};a.s(["default",0,b])},60168,a=>{"use strict";var b=a.i(7997),c=a.i(95936),d=a.i(3236),e=a.i(23351),f=a.i(64254),g=a.i(96270);async function h(a){try{let b=await fetch(`${process.env.API_URL}/api/v1/pages/${a}/`,{next:{revalidate:300}});if(!b.ok)return null;return b.json()}catch{return null}}async function i(){try{let a=await fetch(`${process.env.API_URL}/api/v1/reports/`,{next:{revalidate:300}});if(!a.ok)return[];return(await a.json()).slice(0,3)}catch{return[]}}async function j(){try{let a=await fetch(`${process.env.API_URL}/api/v1/events/`,{next:{revalidate:300}});if(!a.ok)return[];return(await a.json()).slice(0,3)}catch{return[]}}async function k(){let a=await h("home");return{title:a?.meta_title||"Місто Сили",description:a?.meta_description||"Громадська організація Місто Сили."}}async function l(){let[a,k,l]=await Promise.all([h("home"),i(),j()]);return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        .home-link:hover { color: var(--teal) !important; }

        /* Звіти — десктоп: горизонтальні */
        .home-report-card {
          display: grid;
          grid-template-columns: 280px 1fr;
          height: 220px;
          overflow: hidden;
        }
        .home-report-card.no-image {
          grid-template-columns: 1fr;
          height: auto;
          min-height: 120px;
        }
        .home-report-photo {
          display: block;
          overflow: hidden;
          height: 220px;
          flex-shrink: 0;
          position: relative;
        }
        .home-report-photo img { transition: transform 0.4s ease; }
        .home-report-photo:hover img { transform: scale(1.04); }

        /* Звіти — мобільний: вертикальні */
        @media (max-width: 640px) {
          .home-report-card {
            grid-template-columns: 1fr !important;
            height: auto !important;
          }
          .home-report-card h3 {
            display: '-webkit-box',
            webkitLineClamp: 2;
            webkitBoxOrient: 'vertical';
            overflow: 'hidden';
          }
          .home-report-photo {
            height: 220px !important;
          }
        }
      `}),a?.sections?.length?(0,b.jsx)(g.PageRenderer,{sections:a.sections}):(0,b.jsx)("section",{style:{background:"linear-gradient(135deg, var(--charcoal-dark) 0%, #2a2a2a 60%, var(--teal-dark) 100%)",color:"#fff",padding:"clamp(4rem, 10vw, 8rem) 0"},children:(0,b.jsx)("div",{className:"container",children:(0,b.jsxs)("div",{style:{maxWidth:"700px"},children:[(0,b.jsxs)("h1",{style:{fontSize:"clamp(2.5rem, 6vw, 5rem)",fontWeight:700,lineHeight:1.1,marginBottom:"1.5rem"},children:["Місто ",(0,b.jsx)("span",{style:{color:"var(--teal)"},children:"Сили"})]}),(0,b.jsx)("p",{style:{fontSize:"1.25rem",color:"rgba(255,255,255,0.8)",marginBottom:"2rem"},children:"Громадська організація що об'єднує людей."}),(0,b.jsxs)(c.default,{href:"/about",className:"btn-primary",children:["Про нас ",(0,b.jsx)(e.ArrowRight,{size:16})]})]})})}),k.length>0&&(0,b.jsx)("section",{className:"section",style:{background:"var(--off-white)"},children:(0,b.jsxs)("div",{className:"container",children:[(0,b.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:"2.5rem",flexWrap:"wrap",gap:"1rem"},children:[(0,b.jsx)("h2",{className:"section-title",style:{marginBottom:0},children:"Останні звіти"}),(0,b.jsxs)(c.default,{href:"/reports",style:{display:"flex",alignItems:"center",gap:"0.5rem",color:"var(--teal)",fontWeight:700,textDecoration:"none",fontSize:"1rem",textTransform:"uppercase",letterSpacing:"0.05em"},children:["Всі звіти ",(0,b.jsx)(e.ArrowRight,{size:16})]})]}),(0,b.jsx)("ul",{style:{listStyle:"none",display:"flex",flexDirection:"column",gap:"2rem"},children:k.map((a,e)=>(0,b.jsx)("li",{children:(0,b.jsxs)("article",{className:`card home-report-card${!a.image?" no-image":""}`,children:[a.image&&(0,b.jsx)(c.default,{href:`/reports/${a.slug}`,tabIndex:-1,"aria-hidden":"true",className:"home-report-photo",children:(0,b.jsx)(d.default,{src:a.image,alt:a.title,fill:!0,sizes:"(max-width: 640px) 100vw, 280px",priority:0===e,style:{objectFit:"cover"}})}),(0,b.jsxs)("div",{style:{padding:"1.5rem 2rem",display:"flex",flexDirection:"column",justifyContent:"center",overflow:"hidden",minWidth:0},children:[a.date_published&&(0,b.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.5rem",marginBottom:"0.5rem"},children:[(0,b.jsx)(f.Calendar,{size:14,style:{color:"var(--teal)",flexShrink:0}}),(0,b.jsx)("time",{style:{fontSize:"1rem",color:"var(--teal)",fontWeight:500,textTransform:"uppercase",letterSpacing:"0.05em"},children:new Date(a.date_published).toLocaleDateString("uk-UA",{day:"numeric",month:"long",year:"numeric"})})]}),(0,b.jsx)("h3",{style:{fontSize:"clamp(1.125rem, 2vw, 1.5rem)",fontWeight:700,lineHeight:1.3,marginBottom:"0.625rem",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:(0,b.jsx)(c.default,{href:`/reports/${a.slug}`,style:{color:"var(--charcoal-dark)",textDecoration:"none"},className:"home-link",children:a.title})}),(0,b.jsx)("p",{style:{fontSize:"1rem",color:"var(--charcoal)",lineHeight:1.6,display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical",overflow:"hidden"},children:a.preview})]})]})},a.id))})]})}),l.length>0&&(0,b.jsx)("section",{className:"section",children:(0,b.jsxs)("div",{className:"container",children:[(0,b.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:"2.5rem",flexWrap:"wrap",gap:"1rem"},children:[(0,b.jsx)("h2",{className:"section-title",style:{marginBottom:0},children:"Найближчі події"}),(0,b.jsxs)(c.default,{href:"/events",style:{display:"flex",alignItems:"center",gap:"0.5rem",color:"var(--teal)",fontWeight:700,textDecoration:"none",fontSize:"1rem",textTransform:"uppercase",letterSpacing:"0.05em"},children:["Всі події ",(0,b.jsx)(e.ArrowRight,{size:16})]})]}),(0,b.jsx)("ul",{style:{listStyle:"none",display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(280px, 1fr))",gap:"1.5rem",alignItems:"stretch"},children:l.map((a,e)=>{let g,h={day:(g=new Date(a.date)).toLocaleDateString("uk-UA",{day:"numeric"}),month:g.toLocaleDateString("uk-UA",{month:"long"})};return(0,b.jsx)("li",{style:{display:"flex"},children:(0,b.jsxs)("article",{className:"card",style:{display:"flex",flexDirection:"column",width:"100%",overflow:"hidden"},children:[(0,b.jsxs)(c.default,{href:`/events/${a.slug}`,tabIndex:-1,"aria-hidden":"true",style:{display:"block",position:"relative",flexShrink:0,height:200,overflow:"hidden",background:"var(--light-gray)"},children:[a.image?(0,b.jsx)(d.default,{src:a.image,alt:a.title,fill:!0,sizes:"(max-width: 640px) 100vw, 320px",priority:0===e,style:{objectFit:"cover",objectPosition:"center"}}):(0,b.jsx)("div",{style:{width:"100%",height:"100%",background:"var(--off-white)",display:"flex",alignItems:"center",justifyContent:"center"},children:(0,b.jsx)(f.Calendar,{size:48,style:{color:"var(--border)"}})}),(0,b.jsxs)("div",{style:{position:"absolute",top:"1rem",left:"1rem",background:"var(--teal)",color:"#fff",padding:"0.5rem 0.75rem",textAlign:"center",minWidth:"52px"},children:[(0,b.jsx)("div",{style:{fontSize:"1.5rem",fontWeight:700,lineHeight:1},children:h.day}),(0,b.jsx)("div",{style:{fontSize:"1rem",textTransform:"uppercase",letterSpacing:"0.05em"},children:h.month.slice(0,3)})]})]}),(0,b.jsx)("div",{style:{padding:"1.25rem",flex:1},children:(0,b.jsx)("h3",{style:{fontSize:"1.125rem",fontWeight:700,lineHeight:1.3,display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",overflow:"hidden"},children:(0,b.jsx)(c.default,{href:`/events/${a.slug}`,style:{color:"var(--charcoal-dark)",textDecoration:"none"},className:"home-link",children:a.title})})})]})},a.id)})})]})})]})}a.s(["default",0,l,"generateMetadata",0,k])},28004,a=>{a.n(a.i(60168))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0tm7b_x._.js.map