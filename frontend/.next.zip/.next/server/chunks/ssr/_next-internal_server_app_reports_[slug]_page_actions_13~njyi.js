module.exports=[60359,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reports_%5Bslug%5D_page_actions_13~njyi.js.map