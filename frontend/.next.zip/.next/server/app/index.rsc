1:"$Sreact.fragment"
4:I[97367,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"OutletBoundary"]
5:"$Sreact.suspense"
7:I[97367,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"ViewportBoundary"]
9:I[97367,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"MetadataBoundary"]
b:I[68027,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default",1]
:HL["/_next/static/chunks/0pkv494~nrzve.css","style"]
0:{"P":null,"c":["",""],"q":"","i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0pkv494~nrzve.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0yk-8xks3v_~b.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/0d3shmwh5_nmn.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/08-742m-v8yao.js","async":true,"nonce":"$undefined"}]],"$L2"]}],{"children":[["$","$1","c",{"children":["$L3",[["$","script","script-0",{"src":"/_next/static/chunks/0tkbf1af~7blx.js","async":true,"nonce":"$undefined"}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],{},null,false,null]},null,false,null],["$","$1","h",{"children":[null,["$","$L7",null,{"children":"$L8"}],["$","div",null,{"hidden":true,"children":["$","$L9",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$La"}]}]}],null]}],false]],"m":"$undefined","G":["$b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0pkv494~nrzve.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"jjS9nrPylH5BNIvF-Nnc4"}
8:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
c:I[3374,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default"]
d:I[39756,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default"]
e:I[37457,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default"]
f:I[22016,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],""]
10:I[5014,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"default"]
2:["$","html",null,{"lang":"uk","data-scroll-behavior":"smooth","children":[["$","head",null,{"children":["$","script",null,{"type":"application/ld+json","dangerouslySetInnerHTML":{"__html":"{\"@context\":\"https://schema.org\",\"@graph\":[{\"@type\":\"NGO\",\"@id\":\"https://dity.mistosyly.org//#organization\",\"name\":\"Місто Сили\",\"url\":\"https://dity.mistosyly.org/\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://dity.mistosyly.org//images/logo.png\"},\"email\":\"office@mistosyly.org\",\"telephone\":\"+380 95 216 46 11\",\"sameAs\":[\"https://www.facebook.com/mistosyly.ngo/\",\"https://www.instagram.com/misto.syly/\",\"https://www.youtube.com/@misto_syly\"]},{\"@type\":\"WebSite\",\"@id\":\"https://dity.mistosyly.org//#website\",\"url\":\"https://dity.mistosyly.org/\",\"name\":\"Місто Сили\",\"publisher\":{\"@id\":\"https://dity.mistosyly.org//#organization\"},\"potentialAction\":{\"@type\":\"SearchAction\",\"target\":{\"@type\":\"EntryPoint\",\"urlTemplate\":\"https://dity.mistosyly.org//search?q={search_term_string}\"},\"query-input\":\"required name=search_term_string\"}}]}"}}]}],["$","body",null,{"style":{"display":"flex","flexDirection":"column","minHeight":"100vh"},"children":[["$","$Lc",null,{"pages":[{"key":"about","title":"Про нас"},{"key":"home","title":"Головна"}]}],["$","main",null,{"id":"main-content","style":{"flex":1},"children":["$","$Ld",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Le",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","section",null,{"className":"section","children":["$","div",null,{"className":"container","style":{"textAlign":"center","padding":"6rem 1.5rem"},"children":[["$","div",null,{"style":{"fontSize":"clamp(6rem, 20vw, 12rem)","fontWeight":700,"lineHeight":1,"color":"var(--teal)","opacity":0.15,"fontFamily":"var(--font-main)","userSelect":"none","marginBottom":"-2rem"},"children":"404"}],["$","h1",null,{"style":{"fontSize":"clamp(1.75rem, 4vw, 2.5rem)","fontWeight":700,"color":"var(--charcoal-dark)","marginBottom":"1rem"},"children":"Сторінку не знайдено"}],["$","p",null,{"style":{"fontSize":"1.125rem","color":"var(--charcoal)","maxWidth":"480px","margin":"0 auto 2.5rem","lineHeight":1.7},"children":"Сторінка яку ви шукаєте не існує або була переміщена."}],["$","div",null,{"style":{"display":"flex","gap":"1rem","justifyContent":"center","flexWrap":"wrap"},"children":[["$","$Lf",null,{"href":"/","className":"btn-primary","children":[["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"m12 19-7-7 7-7","key":"1l729n"}],["path",{"d":"M19 12H5","key":"x3x0zl"}]],"className":"lucide-arrow-left","size":16}],"На головну"]}],["$","$Lf",null,{"href":"/reports","className":"btn-outline","children":[["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"m21 21-4.34-4.34","key":"14j7rj"}],["circle",{"cx":"11","cy":"11","r":"8","key":"4ej97u"}]],"className":"lucide-search","size":16}],"Переглянути звіти"]}]]}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],"$L11"]}]]}]
12:I[5500,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"Image"]
13:I[54374,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"FooterSocials"]
14:I[54374,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"FooterNav"]
11:["$","footer",null,{"style":{"background":"var(--charcoal-dark)","color":"var(--white)","paddingTop":"4rem","paddingBottom":"2rem","marginTop":"auto"},"children":[["$","div",null,{"className":"container","children":[["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"repeat(auto-fit, minmax(240px, 1fr))","gap":"3rem","paddingBottom":"3rem","borderBottom":"1px solid rgba(255,255,255,0.1)"},"children":[["$","div",null,{"children":[["$","$Lf",null,{"href":"/","aria-label":"Місто Сили — головна","children":["$","$L12",null,{"src":"/images/logo.png","alt":"Місто Сили","width":160,"height":54,"style":{"objectFit":"contain","height":"48px","width":"auto","filter":"brightness(0) invert(1)"}}]}],["$","p",null,{"style":{"marginTop":"1rem","fontSize":"1rem","color":"rgba(255,255,255,0.65)","lineHeight":1.7},"children":"Громадська організація, що об'єднує людей для розбудови сильних спільнот."}],["$","$L13",null,{"facebook":"https://www.facebook.com/mistosyly.ngo/","instagram":"https://www.instagram.com/misto.syly/","youtube":"https://www.youtube.com/@misto_syly","telegram":""}]]}],["$","nav",null,{"aria-label":"Навігація в футері","children":[["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"color":"var(--teal-light)","textTransform":"uppercase","letterSpacing":"0.1em","marginBottom":"1.25rem"},"children":"Навігація"}],["$","$L14",null,{}]]}],["$","address",null,{"style":{"fontStyle":"normal"},"children":[["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"color":"var(--teal-light)","textTransform":"uppercase","letterSpacing":"0.1em","marginBottom":"1.25rem"},"children":"Контакти"}],["$","ul",null,{"style":{"listStyle":"none","display":"flex","flexDirection":"column","gap":"1.25rem","padding":0,"margin":0},"children":[["$","li",null,{"style":{"display":"flex","alignItems":"center","gap":"0.75rem"},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","justifyContent":"center","width":"20px","height":"20px","flexShrink":0},"children":["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7","key":"132q7q"}],["rect",{"x":"2","y":"4","width":"20","height":"16","rx":"2","key":"izxlao"}]],"className":"lucide-mail","size":18,"style":{"color":"var(--teal-light)"}}]}],["$","a",null,{"href":"mailto:office@mistosyly.org","className":"footer-link","style":{"color":"rgba(255,255,255,0.65)","fontSize":"1rem","textDecoration":"none","lineHeight":"1.2"},"children":"office@mistosyly.org"}]]}],["$","li",null,{"style":{"display":"flex","alignItems":"center","gap":"0.75rem"},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","justifyContent":"center","width":"20px","height":"20px","flexShrink":0},"children":["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384","key":"9njp5v"}]],"className":"lucide-phone","size":18,"style":{"color":"var(--teal-light)"}}]}],["$","a",null,{"href":"tel:+380 95 216 46 11","className":"footer-link","style":{"color":"rgba(255,255,255,0.65)","fontSize":"1rem","textDecoration":"none","lineHeight":"1.2"},"children":"+380 95 216 46 11"}]]}],""]}]]}]]}],["$","div",null,{"style":{"paddingTop":"2rem","paddingBottom":"2rem","borderBottom":"1px solid rgba(255,255,255,0.1)"},"className":"footer-partner-logos","children":[[["$","div","/images/de_logo.png",{"className":"footer-partner-logo-item","children":["$","$L12",null,{"src":"/images/de_logo.png","alt":"Співпраця з Німеччиною","fill":true,"sizes":"(max-width: 640px) 45vw, 180px","style":{"objectFit":"contain","opacity":0.85}}]}],["$","div","/images/eu_logo.png",{"className":"footer-partner-logo-item","children":["$","$L12",null,{"src":"/images/eu_logo.png","alt":"Співфінансується Європейським Союзом","fill":true,"sizes":"(max-width: 640px) 45vw, 180px","style":{"objectFit":"contain","opacity":0.85}}]}],["$","div","/images/giz_logo.png",{"className":"footer-partner-logo-item","children":["$","$L12",null,{"src":"/images/giz_logo.png","alt":"GIZ — Deutsche Gesellschaft für Internationale Zusammenarbeit","fill":true,"sizes":"(max-width: 640px) 45vw, 180px","style":{"objectFit":"contain","opacity":0.85}}]}],["$","div","/images/empower_logo.png",{"className":"footer-partner-logo-item","children":["$","$L12",null,{"src":"/images/empower_logo.png","alt":"Empower","fill":true,"sizes":"(max-width: 640px) 45vw, 180px","style":{"objectFit":"contain","opacity":0.85}}]}]],"$L15"]}],"$L16"]}],"$L17"]}]
15:["$","div",null,{"className":"footer-partner-logo-item footer-partner-logo-item--last","children":["$","$L12",null,{"src":"/images/logo.png","alt":"Місто Сили","fill":true,"sizes":"(max-width: 640px) 45vw, 180px","style":{"objectFit":"contain","opacity":0.85}}]}]
16:["$","div",null,{"style":{"paddingTop":"2rem","display":"flex","justifyContent":"space-between","alignItems":"center","flexWrap":"wrap","gap":"1rem"},"children":[["$","p",null,{"style":{"fontSize":"1rem","color":"rgba(255,255,255,0.4)"},"children":["© ",2026," ","Місто Сили",". Всі права захищено."]}],["$","p",null,{"style":{"fontSize":"1rem","color":"rgba(255,255,255,0.4)"},"children":"Громадська організація"}]]}]
17:["$","style",null,{"children":"\n        .footer-partner-logos {\n          --partner-logo-h: 52px;\n          display: flex;\n          flex-wrap: wrap;\n          align-items: center;\n          justify-content: center;\n          gap: 2rem;\n        }\n\n        .footer-partner-logo-item {\n          position: relative;\n          height: var(--partner-logo-h);\n          width: 180px;\n          max-width: 100%;\n          flex-shrink: 0;\n        }\n\n        @media (max-width: 640px) {\n          .footer-partner-logos {\n            --partner-logo-h: 44px;\n            display: grid;\n            grid-template-columns: repeat(2, 1fr);\n            gap: 1.5rem 1rem;\n            justify-items: center;\n            align-items: center;\n          }\n\n          .footer-partner-logo-item {\n            width: 100%;\n            max-width: 150px;\n            padding: 0.25rem 0.5rem;\n          }\n\n          .footer-partner-logo-item--last {\n            grid-column: 1 / -1;\n            padding-top: 0.5rem;\n          }\n        }\n      "}]
18:T4ed,
        .home-link:hover { color: var(--teal) !important; }

        /* Звіти — десктоп: горизонтальні */
        .home-report-card {
          display: grid;
          grid-template-columns: 280px 1fr;
          height: 220px;
          overflow: hidden;
        }
        .home-report-card.no-image {
          grid-template-columns: 1fr;
          height: auto;
          min-height: 120px;
        }
        .home-report-photo {
          display: block;
          overflow: hidden;
          height: 220px;
          flex-shrink: 0;
          position: relative;
        }
        .home-report-photo img { transition: transform 0.4s ease; }
        .home-report-photo:hover img { transform: scale(1.04); }

        /* Звіти — мобільний: вертикальні */
        @media (max-width: 640px) {
          .home-report-card {
            grid-template-columns: 1fr !important;
            height: auto !important;
          }
          .home-report-card h3 {
            display: '-webkit-box',
            webkitLineClamp: 2;
            webkitBoxOrient: 'vertical';
            overflow: 'hidden';
          }
          .home-report-photo {
            height: 220px !important;
          }
        }
      3:[["$","style",null,{"children":"$18"}],[[["$","section","1",{"style":{"background":"linear-gradient(135deg, var(--charcoal-dark) 0%, #2a2a2a 60%, var(--teal-dark) 100%)","color":"#fff","padding":"clamp(3rem, 8vw, 6rem) 0","position":"relative","overflow":"hidden"},"children":[null,["$","div",null,{"className":"container","style":{"position":"relative","zIndex":1},"children":["$","div",null,{"style":{"maxWidth":"700px"},"children":[["$","span",null,{"style":{"display":"inline-block","background":"var(--teal)","color":"#fff","padding":"0.375rem 1rem","fontSize":"0.9rem","fontWeight":700,"textTransform":"uppercase","letterSpacing":"0.1em","marginBottom":"1.5rem"},"children":"Громадська організація «Місто Сили»"}],["$","h1",null,{"style":{"fontSize":"clamp(2.2rem, 5.2vw, 4.4rem)","fontWeight":700,"lineHeight":1.1,"marginBottom":"1.5rem","color":"#fff"},"children":"Центр розвитку дітей та молоді, та їх батьків."}],["$","div",null,{"style":{"fontSize":"clamp(0.95rem, 1.5vw, 1.1rem)","color":"rgba(255,255,255,0.85)","lineHeight":1.7,"marginBottom":"2.5rem"},"dangerouslySetInnerHTML":{"__html":"<p>&nbsp;</p>"}}],["$","$Lf",null,{"href":"/about","className":"btn-primary","children":["Дізнатися більше"," ",["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"M5 12h14","key":"1ays0h"}],["path",{"d":"m12 5 7 7-7 7","key":"xquz4c"}]],"className":"lucide-arrow-right","size":16}]]}]]}]}]]}],["$","section","2",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Про центр"}],["$","p",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"marginBottom":"1rem"},"children":"Ми поруч, щоб підтримати кожну родину"}],["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>В умовах тривалого воєнного конфлікту понад 40% українських дітей втратили доступ до освіти, а близько 36% пережили травматичні події війни. Херсон — один із найбільш постраждалих регіонів. Наш центр працює з червня 2024 року і охопив понад 400 жінок і дітей.</h3>"}}],""]}],false]}]}]}],["$","section","3",{"style":{"background":"var(--teal)","padding":"clamp(3rem, 6vw, 4.5rem) 0"},"children":["$","div",null,{"className":"container","style":{"textAlign":"center"},"children":[["$","h2",null,{"style":{"fontSize":"clamp(1.75rem, 3.4vw, 2.6rem)","fontWeight":700,"color":"#fff","marginBottom":"0.75rem"},"children":"Наша мета"}],"",["$","div",null,{"style":{"color":"rgba(255,255,255,0.85)","fontSize":"0.95rem","marginBottom":"1.5rem"},"dangerouslySetInnerHTML":{"__html":"<h3>Сприяти емоційному відновленню, розвитку навичок подолання стресу та зміцненню психосоціального благополуччя дітей і батьків&nbsp;</h3><h3>через комплексну програму підтримки, розвитку та інтеграції</h3>"}}],""]}]}],"$L19","$L1a","$L1b","$L1c","$L1d"],"$L1e"],"$L1f","$L20"]
21:I[11581,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"GallerySectionClient"]
19:["$","section","4",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Для кого ми працюємо"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>Діти 4–12 років — які втратили доступ до освіти або мають емоційні травми.&nbsp;</h3><h3>Батьки (переважно матері) — які потребують емоційної, освітньої та правової підтримки.&nbsp;</h3><h3>Охоплення: близько 250 дітей та 140 дорослих.</h3>"}}],""]}],false]}]}]}]
1a:["$","section","5",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Основні активності"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>Психосоціальна підтримка — індивідуальні та групові консультації психологів, арт-терапія, робота з тривожністю та страхами.</h3><h3>-</h3><h3>Підготовка до школи — розвиток мовлення, уваги, пам'яті та логічного мислення у формі ігор і творчих завдань.</h3><h3>-</h3><h3>Музична студія — вокальні та інструментальні заняття, індивідуальні й групові репетиції, творчі проєкти.</h3><h3>-</h3><h3>Креативні майстер-класи для дітей — розвиток уяви, художні техніки, командна робота та самовираження.</h3><h3>-</h3><h3>Креативні майстер-класи для дорослих — арт-терапевтичний ефект, зняття стресу, відновлення емоційного балансу.</h3><h3>-</h3><h3>Фітнес для жінок і дітей — фізична підготовка, релаксація, командні ігри.</h3><h3>-</h3><h3>Програма «Сила бути» — практичні заняття для батьків: нутриціологія, самомасаж, дихальні практики, основи жіночого здоров'я.</h3>"}}],""]}],false]}]}]}]
1b:["$","$L21","6",{"images":[{"id":1,"image":"https://api.mistosyly.org/media/images/carousel/img20260109191643734_16c27204.jpg","alt":"foto1","caption":"","order":0},{"id":2,"image":"https://api.mistosyly.org/media/images/carousel/img20260109191644141_59c8137f.jpg","alt":"foto2","caption":"","order":0},{"id":3,"image":"https://api.mistosyly.org/media/images/carousel/img20260123195647267_29340343.jpg","alt":"foto3","caption":"","order":0},{"id":4,"image":"https://api.mistosyly.org/media/images/carousel/img20260130174046791_4950a83e.jpg","alt":"foto4","caption":"","order":0}],"title":"Галерея","subtitle":""}]
1c:["$","section","7",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Результати роботи"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>250 дітей охоплено програмами центру<br>140 батьків отримали підтримку<br>250+ групових та індивідуальних сесій проведено<br>75% учасників відзначили зниження рівня тривожності<br>85% рівень задоволеності учасників</h3>"}}],""]}],false]}]}]}]
1d:["$","section","8",{"className":"section","style":{"background":"var(--off-white)","padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","style":{"textAlign":"center"},"children":[["$","h2",null,{"className":"section-title centered","children":"Зв'яжіться з нами"}],["$","div",null,{"className":"cms-content","style":{"maxWidth":"600px","margin":"0 auto 1.5rem"},"dangerouslySetInnerHTML":{"__html":"<h2>Ми відкриті до співпраці та партнерства</h2>"}}],["$","$Lf",null,{"href":"/contacts","className":"btn-primary","children":["Зв'язатися з нами ",["$","$L10",null,{"ref":"$undefined","iconNode":"$3:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}]}]
22:T1a9d,
        .cms-content {
          font-family: var(--font-main);
          font-size: 0.95rem;
          line-height: 1.7;
          color: var(--charcoal);
        }
        /* H1 в контенті - менший за глобальний h1 */
        .cms-content h1 {
          font-size: clamp(1.5rem, 3vw, 2.4rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.5rem 0 0.75rem;
        }
        /* H2 в контенті - менший за глобальний h2 */
        .cms-content h2 {
          font-size: clamp(1.3rem, 2.6vw, 1.95rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.25rem 0 0.75rem;
        }
        /* H3 в контенті - менший за глобальний h3 */
        .cms-content h3 {
          font-size: clamp(1.05rem, 1.9vw, 1.35rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1rem 0 0.5rem;
        }
        /* H4 в контенті - менший за глобальний h4 */
        .cms-content h4 {
          font-size: clamp(0.95rem, 1.6vw, 1.15rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.75rem 0 0.5rem;
        }
        .cms-content h5, .cms-content h6 {
          font-size: clamp(0.9rem, 1.4vw, 1rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.5rem 0 0.5rem;
        }
        .cms-content p {
          font-size: 0.95rem;
          margin-bottom: 0.75rem;
        }
        .cms-content ul, .cms-content ol {
          font-size: 0.95rem;
          padding-left: 1.5rem;
          margin-bottom: 0.75rem;
        }
        .cms-content li {
          margin-bottom: 0.3rem;
        }
        .cms-content a {
          color: var(--teal);
          font-size: 0.95rem;
        }
        .cms-content img {
          max-width: 100%;
          height: auto;
          margin: 1.25rem auto;
          display: block;
          box-shadow: 0 4px 20px rgba(0,0,0,0.1);
          cursor: zoom-in;
          width: auto !important;
          max-width: 100% !important;
        }
        .cms-content figure {
          margin: 1.25rem 0;
          text-align: center;
        }
        .cms-content figcaption {
          font-size: 0.9rem;
          color: var(--charcoal);
          margin-top: 0.4rem;
          font-style: italic;
        }
        .cms-content .image-style-align-left {
          float: left;
          margin: 0 1.5rem 0.75rem 0;
          max-width: 45%;
        }
        .cms-content .image-style-align-left img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-right {
          float: right;
          margin: 0 0 0.75rem 1.5rem;
          max-width: 45%;
        }
        .cms-content .image-style-align-right img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-center {
          margin: 1.25rem auto;
          display: block;
          max-width: 100%;
        }
        .cms-content .image-style-align-center img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content::after {
          content: '';
          display: table;
          clear: both;
        }
        .cms-content blockquote {
          border-left: 4px solid var(--teal);
          padding: 0.6rem 1.2rem;
          margin: 1rem 0;
          background: var(--off-white);
          font-style: italic;
          font-size: 0.95rem;
        }
        .cms-content table {
          border-collapse: collapse;
          width: 100%;
          font-size: 0.85rem;
          margin: 1.25rem 0;
        }
        .cms-content td, .cms-content th {
          border: 1px solid var(--border);
          padding: 0.5rem 0.8rem;
          text-align: left;
        }
        .cms-content th {
          background: var(--off-white);
          font-weight: 700;
        }

        /* Зменшені відступи для .section-title */
        .section-title {
          margin-bottom: 2rem;
        }
        .section-title::after {
          margin-top: 0.75rem;
        }
        .section-title.centered::after {
          margin: 0.75rem auto 0;
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns: 1fr 1fr"] {
            grid-template-columns: 1fr !important;
          }
          .cms-content {
            font-size: 0.9rem;
          }
          .cms-content h1 {
            font-size: clamp(1.35rem, 4.5vw, 1.8rem);
          }
          .cms-content h2 {
            font-size: clamp(1.2rem, 3.5vw, 1.6rem);
          }
          .cms-content h3 {
            font-size: clamp(1rem, 2.8vw, 1.2rem);
          }
          .cms-content p {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content ul, .cms-content ol {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content .image-style-align-left,
          .cms-content .image-style-align-right {
            float: none;
            max-width: 100% !important;
            margin: 0.75rem auto;
            display: block;
          }
          .cms-content .image-style-align-left img,
          .cms-content .image-style-align-right img,
          .cms-content .image-style-align-center img,
          .cms-content img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 0.75rem auto;
          }
          .cms-content figure img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
          }
          .cms-content figure {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0.75rem 0;
          }
          .cms-content table {
            font-size: 0.8rem;
            display: block;
            overflow-x: auto;
            white-space: nowrap;
            margin: 0.75rem 0;
          }
          .cms-content td, .cms-content th {
            padding: 0.3rem 0.5rem;
          }
          .cms-content blockquote {
            font-size: 0.9rem;
            padding: 0.5rem 0.8rem;
            margin: 0.75rem 0;
          }
          .cms-content figcaption {
            font-size: 0.8rem;
            margin-top: 0.3rem;
          }
          .section-title {
            margin-bottom: 1.5rem;
          }
          .section-title::after {
            margin-top: 0.5rem;
            width: 3rem;
          }
        }
      1e:["$","style",null,{"children":"$22"}]
1f:["$","section",null,{"className":"section","style":{"background":"var(--off-white)"},"children":["$","div",null,{"className":"container","children":[["$","div",null,{"style":{"display":"flex","justifyContent":"space-between","alignItems":"flex-end","marginBottom":"2.5rem","flexWrap":"wrap","gap":"1rem"},"children":[["$","h2",null,{"className":"section-title","style":{"marginBottom":0},"children":"Останні звіти"}],["$","$Lf",null,{"href":"/reports","style":{"display":"flex","alignItems":"center","gap":"0.5rem","color":"var(--teal)","fontWeight":700,"textDecoration":"none","fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":["Всі звіти ",["$","$L10",null,{"ref":"$undefined","iconNode":"$3:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}],["$","ul",null,{"style":{"listStyle":"none","display":"flex","flexDirection":"column","gap":"2rem"},"children":[["$","li","4",{"children":["$","article",null,{"className":"card home-report-card","children":[["$","$Lf",null,{"href":"/reports/pidsumki-roboti-muzichnoyi-studiyi-za-gruden-2025","tabIndex":-1,"aria-hidden":"true","className":"home-report-photo","children":["$","$L12",null,{"src":"https://api.mistosyly.org/media/images/posts/photo2026-07-0618-20-58_8e87781f.jpg","alt":"Підсумки роботи музичної студії за грудень 2025","fill":true,"sizes":"(max-width: 640px) 100vw, 280px","priority":true,"style":{"objectFit":"cover"}}]}],["$","div",null,{"style":{"padding":"1.5rem 2rem","display":"flex","flexDirection":"column","justifyContent":"center","overflow":"hidden","minWidth":0},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","gap":"0.5rem","marginBottom":"0.5rem"},"children":[["$","$L10",null,{"ref":"$undefined","iconNode":[["path",{"d":"M8 2v4","key":"1cmpym"}],["path",{"d":"M16 2v4","key":"4m81vk"}],["rect",{"width":"18","height":"18","x":"3","y":"4","rx":"2","key":"1hopcy"}],["path",{"d":"M3 10h18","key":"8toen8"}]],"className":"lucide-calendar","size":14,"style":{"color":"var(--teal)","flexShrink":0}}],["$","time",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"textTransform":"uppercase","letterSpacing":"0.05em"},"children":"1 грудня 2025 р."}]]}],["$","h3",null,{"style":{"fontSize":"clamp(1.125rem, 2vw, 1.5rem)","fontWeight":700,"lineHeight":1.3,"marginBottom":"0.625rem","display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden","textOverflow":"ellipsis","whiteSpace":"nowrap"},"children":["$","$Lf",null,{"href":"/reports/pidsumki-roboti-muzichnoyi-studiyi-za-gruden-2025","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Підсумки роботи музичної студії за грудень 2025"}]}],["$","p",null,{"style":{"fontSize":"1rem","color":"var(--charcoal)","lineHeight":1.6,"display":"-webkit-box","WebkitLineClamp":3,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":"Музична студія Центру «Зростаємо разом» завершила перший семестр. 28 дітей та підлітків розвивали вокальні та інструментальні навички, взяли участь у святковому концерті."}]]}]]}]}],["$","li","1",{"children":["$","article",null,{"className":"card home-report-card","children":[["$","$Lf",null,{"href":"/reports/zvit-pro-diialnist-tsentru-zrostaiemo-razom-za-veresen-zhovten-2025","tabIndex":-1,"aria-hidden":"true","className":"home-report-photo","children":["$","$L12",null,{"src":"https://api.mistosyly.org/media/images/posts/photo2026-07-0617-53-22_b5192fb2.jpg","alt":"Звіт про діяльність Центру «Зростаємо разом» за вересень–жовтень 2025","fill":true,"sizes":"(max-width: 640px) 100vw, 280px","priority":false,"style":{"objectFit":"cover"}}]}],["$","div",null,{"style":{"padding":"1.5rem 2rem","display":"flex","flexDirection":"column","justifyContent":"center","overflow":"hidden","minWidth":0},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","gap":"0.5rem","marginBottom":"0.5rem"},"children":[["$","$L10",null,{"ref":"$undefined","iconNode":"$1f:props:children:props:children:1:props:children:0:props:children:props:children:1:props:children:0:props:children:0:props:iconNode","className":"lucide-calendar","size":14,"style":{"color":"var(--teal)","flexShrink":0}}],["$","time",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"textTransform":"uppercase","letterSpacing":"0.05em"},"children":"31 жовтня 2025 р."}]]}],["$","h3",null,{"style":{"fontSize":"clamp(1.125rem, 2vw, 1.5rem)","fontWeight":700,"lineHeight":1.3,"marginBottom":"0.625rem","display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden","textOverflow":"ellipsis","whiteSpace":"nowrap"},"children":["$","$Lf",null,{"href":"/reports/zvit-pro-diialnist-tsentru-zrostaiemo-razom-za-veresen-zhovten-2025","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Звіт про діяльність Центру «Зростаємо разом» за вересень–жовтень 2025"}]}],"$L23"]}]]}]}]]}]]}]}]
20:["$","section",null,{"className":"section","children":["$","div",null,{"className":"container","children":[["$","div",null,{"style":{"display":"flex","justifyContent":"space-between","alignItems":"flex-end","marginBottom":"2.5rem","flexWrap":"wrap","gap":"1rem"},"children":[["$","h2",null,{"className":"section-title","style":{"marginBottom":0},"children":"Найближчі події"}],["$","$Lf",null,{"href":"/events","style":{"display":"flex","alignItems":"center","gap":"0.5rem","color":"var(--teal)","fontWeight":700,"textDecoration":"none","fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":["Всі події ",["$","$L10",null,{"ref":"$undefined","iconNode":"$3:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}],["$","ul",null,{"style":{"listStyle":"none","display":"grid","gridTemplateColumns":"repeat(auto-fill, minmax(280px, 1fr))","gap":"1.5rem","alignItems":"stretch"},"children":[["$","li","4",{"style":{"display":"flex"},"children":["$","article",null,{"className":"card","style":{"display":"flex","flexDirection":"column","width":"100%","overflow":"hidden"},"children":[["$","$Lf",null,{"href":"/events/trening-sila-buti---praktichni-zaniattia-dlia-mam","tabIndex":-1,"aria-hidden":"true","style":{"display":"block","position":"relative","flexShrink":0,"height":200,"overflow":"hidden","background":"var(--light-gray)"},"children":[["$","$L12",null,{"src":"https://api.mistosyly.org/media/images/events/photo_2026-07-06_18-18-11.jpg","alt":"Тренінг «Сила бути» - практичні заняття для мам","fill":true,"sizes":"(max-width: 640px) 100vw, 320px","priority":true,"style":{"objectFit":"cover","objectPosition":"center"}}],["$","div",null,{"style":{"position":"absolute","top":"1rem","left":"1rem","background":"var(--teal)","color":"#fff","padding":"0.5rem 0.75rem","textAlign":"center","minWidth":"52px"},"children":[["$","div",null,{"style":{"fontSize":"1.5rem","fontWeight":700,"lineHeight":1},"children":"1"}],["$","div",null,{"style":{"fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":"кві"}]]}]]}],["$","div",null,{"style":{"padding":"1.25rem","flex":1},"children":["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"lineHeight":1.3,"display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":["$","$Lf",null,{"href":"/events/trening-sila-buti---praktichni-zaniattia-dlia-mam","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Тренінг «Сила бути» - практичні заняття для мам"}]}]}]]}]}],["$","li","3",{"style":{"display":"flex"},"children":["$","article",null,{"className":"card","style":{"display":"flex","flexDirection":"column","width":"100%","overflow":"hidden"},"children":[["$","$Lf",null,{"href":"/events/tvorchii-maister-klas-dlia-ditei-vesniani-fantaziyi","tabIndex":-1,"aria-hidden":"true","style":{"display":"block","position":"relative","flexShrink":0,"height":200,"overflow":"hidden","background":"var(--light-gray)"},"children":[["$","$L12",null,{"src":"https://api.mistosyly.org/media/images/events/photo_2026-07-06_18-10-01_P0EPdra.jpg","alt":"Творчий майстер-клас для дітей «Весняні фантазії»","fill":true,"sizes":"(max-width: 640px) 100vw, 320px","priority":false,"style":{"objectFit":"cover","objectPosition":"center"}}],["$","div",null,{"style":{"position":"absolute","top":"1rem","left":"1rem","background":"var(--teal)","color":"#fff","padding":"0.5rem 0.75rem","textAlign":"center","minWidth":"52px"},"children":[["$","div",null,{"style":{"fontSize":"1.5rem","fontWeight":700,"lineHeight":1},"children":"2"}],["$","div",null,{"style":{"fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":"бер"}]]}]]}],["$","div",null,{"style":{"padding":"1.25rem","flex":1},"children":["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"lineHeight":1.3,"display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":["$","$Lf",null,{"href":"/events/tvorchii-maister-klas-dlia-ditei-vesniani-fantaziyi","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Творчий майстер-клас для дітей «Весняні фантазії»"}]}]}]]}]}]]}]]}]}]
23:["$","p",null,{"style":{"fontSize":"1rem","color":"var(--charcoal)","lineHeight":1.6,"display":"-webkit-box","WebkitLineClamp":3,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":"За перші два місяці роботи центру охоплено понад 120 дітей та 80 дорослих. Проведено групові та індивідуальні сесії психологічної підтримки, творчі майстер-класи та заняття з підготовки до школи."}]
24:I[27201,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"IconMark"]
6:null
a:[["$","title","0",{"children":"Головна сторінка"}],["$","meta","1",{"name":"description","content":"Головна сторінка центру розвитку матері та дитини «Зростаємо разом»"}],["$","meta","2",{"name":"author","content":"Місто Сили"}],["$","meta","3",{"name":"keywords","content":"громадська організація,місто сили,спільнота,волонтери"}],["$","meta","4",{"property":"og:title","content":"Головна сторінка"}],["$","meta","5",{"property":"og:description","content":"Головна сторінка центру розвитку матері та дитини «Зростаємо разом»"}],["$","meta","6",{"property":"og:site_name","content":"Місто Сили"}],["$","meta","7",{"property":"og:locale","content":"uk_UA"}],["$","meta","8",{"property":"og:type","content":"website"}],["$","meta","9",{"name":"twitter:card","content":"summary"}],["$","meta","10",{"name":"twitter:title","content":"Головна сторінка"}],["$","meta","11",{"name":"twitter:description","content":"Головна сторінка центру розвитку матері та дитини «Зростаємо разом»"}],["$","link","12",{"rel":"icon","href":"/favicon.ico?favicon.0s7a~2j35nq2y.ico","sizes":"532x490","type":"image/x-icon"}],["$","$L24","13",{}]]
