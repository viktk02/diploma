1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default"]
3:I[37457,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"jjS9nrPylH5BNIvF-Nnc4"}
