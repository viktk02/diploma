1:"$Sreact.fragment"
3:I[22016,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],""]
4:I[5014,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"default"]
f:I[11581,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"GallerySectionClient"]
11:I[5500,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js","/_next/static/chunks/0tkbf1af~7blx.js"],"Image"]
13:I[97367,["/_next/static/chunks/0yk-8xks3v_~b.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/08-742m-v8yao.js"],"OutletBoundary"]
14:"$Sreact.suspense"
2:T4ed,
        .home-link:hover { color: var(--teal) !important; }

        /* Звіти — десктоп: горизонтальні */
        .home-report-card {
          display: grid;
          grid-template-columns: 280px 1fr;
          height: 220px;
          overflow: hidden;
        }
        .home-report-card.no-image {
          grid-template-columns: 1fr;
          height: auto;
          min-height: 120px;
        }
        .home-report-photo {
          display: block;
          overflow: hidden;
          height: 220px;
          flex-shrink: 0;
          position: relative;
        }
        .home-report-photo img { transition: transform 0.4s ease; }
        .home-report-photo:hover img { transform: scale(1.04); }

        /* Звіти — мобільний: вертикальні */
        @media (max-width: 640px) {
          .home-report-card {
            grid-template-columns: 1fr !important;
            height: auto !important;
          }
          .home-report-card h3 {
            display: '-webkit-box',
            webkitLineClamp: 2;
            webkitBoxOrient: 'vertical';
            overflow: 'hidden';
          }
          .home-report-photo {
            height: 220px !important;
          }
        }
      0:{"rsc":["$","$1","c",{"children":[[["$","style",null,{"children":"$2"}],[[["$","section","1",{"style":{"background":"linear-gradient(135deg, var(--charcoal-dark) 0%, #2a2a2a 60%, var(--teal-dark) 100%)","color":"#fff","padding":"clamp(3rem, 8vw, 6rem) 0","position":"relative","overflow":"hidden"},"children":[null,["$","div",null,{"className":"container","style":{"position":"relative","zIndex":1},"children":["$","div",null,{"style":{"maxWidth":"700px"},"children":[["$","span",null,{"style":{"display":"inline-block","background":"var(--teal)","color":"#fff","padding":"0.375rem 1rem","fontSize":"0.9rem","fontWeight":700,"textTransform":"uppercase","letterSpacing":"0.1em","marginBottom":"1.5rem"},"children":"Громадська організація «Місто Сили»"}],["$","h1",null,{"style":{"fontSize":"clamp(2.2rem, 5.2vw, 4.4rem)","fontWeight":700,"lineHeight":1.1,"marginBottom":"1.5rem","color":"#fff"},"children":"Центр розвитку дітей та молоді, та їх батьків."}],["$","div",null,{"style":{"fontSize":"clamp(0.95rem, 1.5vw, 1.1rem)","color":"rgba(255,255,255,0.85)","lineHeight":1.7,"marginBottom":"2.5rem"},"dangerouslySetInnerHTML":{"__html":"<p>&nbsp;</p>"}}],["$","$L3",null,{"href":"/about","className":"btn-primary","children":["Дізнатися більше"," ",["$","$L4",null,{"iconNode":[["path",{"d":"M5 12h14","key":"1ays0h"}],["path",{"d":"m12 5 7 7-7 7","key":"xquz4c"}]],"className":"lucide-arrow-right","size":16}]]}]]}]}]]}],["$","section","2",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Про центр"}],["$","p",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"marginBottom":"1rem"},"children":"Ми поруч, щоб підтримати кожну родину"}],["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>В умовах тривалого воєнного конфлікту понад 40% українських дітей втратили доступ до освіти, а близько 36% пережили травматичні події війни. Херсон — один із найбільш постраждалих регіонів. Наш центр працює з червня 2024 року і охопив понад 400 жінок і дітей.</h3>"}}],""]}],false]}]}]}],["$","section","3",{"style":{"background":"var(--teal)","padding":"clamp(3rem, 6vw, 4.5rem) 0"},"children":["$","div",null,{"className":"container","style":{"textAlign":"center"},"children":[["$","h2",null,{"style":{"fontSize":"clamp(1.75rem, 3.4vw, 2.6rem)","fontWeight":700,"color":"#fff","marginBottom":"0.75rem"},"children":"Наша мета"}],"",["$","div",null,{"style":{"color":"rgba(255,255,255,0.85)","fontSize":"0.95rem","marginBottom":"1.5rem"},"dangerouslySetInnerHTML":{"__html":"<h3>Сприяти емоційному відновленню, розвитку навичок подолання стресу та зміцненню психосоціального благополуччя дітей і батьків&nbsp;</h3><h3>через комплексну програму підтримки, розвитку та інтеграції</h3>"}}],""]}]}],"$L5","$L6","$L7","$L8","$L9"],"$La"],"$Lb","$Lc"],["$Ld"],"$Le"]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jjS9nrPylH5BNIvF-Nnc4"}
5:["$","section","4",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Для кого ми працюємо"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>Діти 4–12 років — які втратили доступ до освіти або мають емоційні травми.&nbsp;</h3><h3>Батьки (переважно матері) — які потребують емоційної, освітньої та правової підтримки.&nbsp;</h3><h3>Охоплення: близько 250 дітей та 140 дорослих.</h3>"}}],""]}],false]}]}]}]
6:["$","section","5",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Основні активності"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>Психосоціальна підтримка — індивідуальні та групові консультації психологів, арт-терапія, робота з тривожністю та страхами.</h3><h3>-</h3><h3>Підготовка до школи — розвиток мовлення, уваги, пам'яті та логічного мислення у формі ігор і творчих завдань.</h3><h3>-</h3><h3>Музична студія — вокальні та інструментальні заняття, індивідуальні й групові репетиції, творчі проєкти.</h3><h3>-</h3><h3>Креативні майстер-класи для дітей — розвиток уяви, художні техніки, командна робота та самовираження.</h3><h3>-</h3><h3>Креативні майстер-класи для дорослих — арт-терапевтичний ефект, зняття стресу, відновлення емоційного балансу.</h3><h3>-</h3><h3>Фітнес для жінок і дітей — фізична підготовка, релаксація, командні ігри.</h3><h3>-</h3><h3>Програма «Сила бути» — практичні заняття для батьків: нутриціологія, самомасаж, дихальні практики, основи жіночого здоров'я.</h3>"}}],""]}],false]}]}]}]
7:["$","$Lf","6",{"images":[{"id":1,"image":"https://api.mistosyly.org/media/images/carousel/img20260109191643734_16c27204.jpg","alt":"foto1","caption":"","order":0},{"id":2,"image":"https://api.mistosyly.org/media/images/carousel/img20260109191644141_59c8137f.jpg","alt":"foto2","caption":"","order":0},{"id":3,"image":"https://api.mistosyly.org/media/images/carousel/img20260123195647267_29340343.jpg","alt":"foto3","caption":"","order":0},{"id":4,"image":"https://api.mistosyly.org/media/images/carousel/img20260130174046791_4950a83e.jpg","alt":"foto4","caption":"","order":0}],"title":"Галерея","subtitle":""}]
8:["$","section","7",{"className":"section","style":{"padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","children":["$","div",null,{"style":{"display":"grid","gridTemplateColumns":"1fr","gap":"3rem","alignItems":"center"},"children":[["$","div",null,{"style":{"maxWidth":"800px"},"children":[["$","h2",null,{"className":"section-title","children":"Результати роботи"}],"",["$","div",null,{"className":"cms-content","dangerouslySetInnerHTML":{"__html":"<h3>250 дітей охоплено програмами центру<br>140 батьків отримали підтримку<br>250+ групових та індивідуальних сесій проведено<br>75% учасників відзначили зниження рівня тривожності<br>85% рівень задоволеності учасників</h3>"}}],""]}],false]}]}]}]
9:["$","section","8",{"className":"section","style":{"background":"var(--off-white)","padding":"clamp(2.5rem, 5vw, 4rem) 0"},"children":["$","div",null,{"className":"container","style":{"textAlign":"center"},"children":[["$","h2",null,{"className":"section-title centered","children":"Зв'яжіться з нами"}],["$","div",null,{"className":"cms-content","style":{"maxWidth":"600px","margin":"0 auto 1.5rem"},"dangerouslySetInnerHTML":{"__html":"<h2>Ми відкриті до співпраці та партнерства</h2>"}}],["$","$L3",null,{"href":"/contacts","className":"btn-primary","children":["Зв'язатися з нами ",["$","$L4",null,{"iconNode":"$0:rsc:props:children:0:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}]}]
10:T1a9d,
        .cms-content {
          font-family: var(--font-main);
          font-size: 0.95rem;
          line-height: 1.7;
          color: var(--charcoal);
        }
        /* H1 в контенті - менший за глобальний h1 */
        .cms-content h1 {
          font-size: clamp(1.5rem, 3vw, 2.4rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.5rem 0 0.75rem;
        }
        /* H2 в контенті - менший за глобальний h2 */
        .cms-content h2 {
          font-size: clamp(1.3rem, 2.6vw, 1.95rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1.25rem 0 0.75rem;
        }
        /* H3 в контенті - менший за глобальний h3 */
        .cms-content h3 {
          font-size: clamp(1.05rem, 1.9vw, 1.35rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 1rem 0 0.5rem;
        }
        /* H4 в контенті - менший за глобальний h4 */
        .cms-content h4 {
          font-size: clamp(0.95rem, 1.6vw, 1.15rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.75rem 0 0.5rem;
        }
        .cms-content h5, .cms-content h6 {
          font-size: clamp(0.9rem, 1.4vw, 1rem);
          font-weight: 700;
          color: var(--charcoal-dark);
          margin: 0.5rem 0 0.5rem;
        }
        .cms-content p {
          font-size: 0.95rem;
          margin-bottom: 0.75rem;
        }
        .cms-content ul, .cms-content ol {
          font-size: 0.95rem;
          padding-left: 1.5rem;
          margin-bottom: 0.75rem;
        }
        .cms-content li {
          margin-bottom: 0.3rem;
        }
        .cms-content a {
          color: var(--teal);
          font-size: 0.95rem;
        }
        .cms-content img {
          max-width: 100%;
          height: auto;
          margin: 1.25rem auto;
          display: block;
          box-shadow: 0 4px 20px rgba(0,0,0,0.1);
          cursor: zoom-in;
          width: auto !important;
          max-width: 100% !important;
        }
        .cms-content figure {
          margin: 1.25rem 0;
          text-align: center;
        }
        .cms-content figcaption {
          font-size: 0.9rem;
          color: var(--charcoal);
          margin-top: 0.4rem;
          font-style: italic;
        }
        .cms-content .image-style-align-left {
          float: left;
          margin: 0 1.5rem 0.75rem 0;
          max-width: 45%;
        }
        .cms-content .image-style-align-left img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-right {
          float: right;
          margin: 0 0 0.75rem 1.5rem;
          max-width: 45%;
        }
        .cms-content .image-style-align-right img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content .image-style-align-center {
          margin: 1.25rem auto;
          display: block;
          max-width: 100%;
        }
        .cms-content .image-style-align-center img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto !important;
        }
        .cms-content::after {
          content: '';
          display: table;
          clear: both;
        }
        .cms-content blockquote {
          border-left: 4px solid var(--teal);
          padding: 0.6rem 1.2rem;
          margin: 1rem 0;
          background: var(--off-white);
          font-style: italic;
          font-size: 0.95rem;
        }
        .cms-content table {
          border-collapse: collapse;
          width: 100%;
          font-size: 0.85rem;
          margin: 1.25rem 0;
        }
        .cms-content td, .cms-content th {
          border: 1px solid var(--border);
          padding: 0.5rem 0.8rem;
          text-align: left;
        }
        .cms-content th {
          background: var(--off-white);
          font-weight: 700;
        }

        /* Зменшені відступи для .section-title */
        .section-title {
          margin-bottom: 2rem;
        }
        .section-title::after {
          margin-top: 0.75rem;
        }
        .section-title.centered::after {
          margin: 0.75rem auto 0;
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns: 1fr 1fr"] {
            grid-template-columns: 1fr !important;
          }
          .cms-content {
            font-size: 0.9rem;
          }
          .cms-content h1 {
            font-size: clamp(1.35rem, 4.5vw, 1.8rem);
          }
          .cms-content h2 {
            font-size: clamp(1.2rem, 3.5vw, 1.6rem);
          }
          .cms-content h3 {
            font-size: clamp(1rem, 2.8vw, 1.2rem);
          }
          .cms-content p {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content ul, .cms-content ol {
            font-size: 0.9rem;
            margin-bottom: 0.6rem;
          }
          .cms-content .image-style-align-left,
          .cms-content .image-style-align-right {
            float: none;
            max-width: 100% !important;
            margin: 0.75rem auto;
            display: block;
          }
          .cms-content .image-style-align-left img,
          .cms-content .image-style-align-right img,
          .cms-content .image-style-align-center img,
          .cms-content img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 0.75rem auto;
          }
          .cms-content figure img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
          }
          .cms-content figure {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0.75rem 0;
          }
          .cms-content table {
            font-size: 0.8rem;
            display: block;
            overflow-x: auto;
            white-space: nowrap;
            margin: 0.75rem 0;
          }
          .cms-content td, .cms-content th {
            padding: 0.3rem 0.5rem;
          }
          .cms-content blockquote {
            font-size: 0.9rem;
            padding: 0.5rem 0.8rem;
            margin: 0.75rem 0;
          }
          .cms-content figcaption {
            font-size: 0.8rem;
            margin-top: 0.3rem;
          }
          .section-title {
            margin-bottom: 1.5rem;
          }
          .section-title::after {
            margin-top: 0.5rem;
            width: 3rem;
          }
        }
      a:["$","style",null,{"children":"$10"}]
b:["$","section",null,{"className":"section","style":{"background":"var(--off-white)"},"children":["$","div",null,{"className":"container","children":[["$","div",null,{"style":{"display":"flex","justifyContent":"space-between","alignItems":"flex-end","marginBottom":"2.5rem","flexWrap":"wrap","gap":"1rem"},"children":[["$","h2",null,{"className":"section-title","style":{"marginBottom":0},"children":"Останні звіти"}],["$","$L3",null,{"href":"/reports","style":{"display":"flex","alignItems":"center","gap":"0.5rem","color":"var(--teal)","fontWeight":700,"textDecoration":"none","fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":["Всі звіти ",["$","$L4",null,{"iconNode":"$0:rsc:props:children:0:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}],["$","ul",null,{"style":{"listStyle":"none","display":"flex","flexDirection":"column","gap":"2rem"},"children":[["$","li","4",{"children":["$","article",null,{"className":"card home-report-card","children":[["$","$L3",null,{"href":"/reports/pidsumki-roboti-muzichnoyi-studiyi-za-gruden-2025","tabIndex":-1,"aria-hidden":"true","className":"home-report-photo","children":["$","$L11",null,{"src":"https://api.mistosyly.org/media/images/posts/photo2026-07-0618-20-58_8e87781f.jpg","alt":"Підсумки роботи музичної студії за грудень 2025","fill":true,"sizes":"(max-width: 640px) 100vw, 280px","priority":true,"style":{"objectFit":"cover"}}]}],["$","div",null,{"style":{"padding":"1.5rem 2rem","display":"flex","flexDirection":"column","justifyContent":"center","overflow":"hidden","minWidth":0},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","gap":"0.5rem","marginBottom":"0.5rem"},"children":[["$","$L4",null,{"iconNode":[["path",{"d":"M8 2v4","key":"1cmpym"}],["path",{"d":"M16 2v4","key":"4m81vk"}],["rect",{"width":"18","height":"18","x":"3","y":"4","rx":"2","key":"1hopcy"}],["path",{"d":"M3 10h18","key":"8toen8"}]],"className":"lucide-calendar","size":14,"style":{"color":"var(--teal)","flexShrink":0}}],["$","time",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"textTransform":"uppercase","letterSpacing":"0.05em"},"children":"1 грудня 2025 р."}]]}],["$","h3",null,{"style":{"fontSize":"clamp(1.125rem, 2vw, 1.5rem)","fontWeight":700,"lineHeight":1.3,"marginBottom":"0.625rem","display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden","textOverflow":"ellipsis","whiteSpace":"nowrap"},"children":["$","$L3",null,{"href":"/reports/pidsumki-roboti-muzichnoyi-studiyi-za-gruden-2025","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Підсумки роботи музичної студії за грудень 2025"}]}],["$","p",null,{"style":{"fontSize":"1rem","color":"var(--charcoal)","lineHeight":1.6,"display":"-webkit-box","WebkitLineClamp":3,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":"Музична студія Центру «Зростаємо разом» завершила перший семестр. 28 дітей та підлітків розвивали вокальні та інструментальні навички, взяли участь у святковому концерті."}]]}]]}]}],["$","li","1",{"children":["$","article",null,{"className":"card home-report-card","children":[["$","$L3",null,{"href":"/reports/zvit-pro-diialnist-tsentru-zrostaiemo-razom-za-veresen-zhovten-2025","tabIndex":-1,"aria-hidden":"true","className":"home-report-photo","children":["$","$L11",null,{"src":"https://api.mistosyly.org/media/images/posts/photo2026-07-0617-53-22_b5192fb2.jpg","alt":"Звіт про діяльність Центру «Зростаємо разом» за вересень–жовтень 2025","fill":true,"sizes":"(max-width: 640px) 100vw, 280px","priority":false,"style":{"objectFit":"cover"}}]}],["$","div",null,{"style":{"padding":"1.5rem 2rem","display":"flex","flexDirection":"column","justifyContent":"center","overflow":"hidden","minWidth":0},"children":[["$","div",null,{"style":{"display":"flex","alignItems":"center","gap":"0.5rem","marginBottom":"0.5rem"},"children":[["$","$L4",null,{"iconNode":"$b:props:children:props:children:1:props:children:0:props:children:props:children:1:props:children:0:props:children:0:props:iconNode","className":"lucide-calendar","size":14,"style":{"color":"var(--teal)","flexShrink":0}}],["$","time",null,{"style":{"fontSize":"1rem","color":"var(--teal)","fontWeight":500,"textTransform":"uppercase","letterSpacing":"0.05em"},"children":"31 жовтня 2025 р."}]]}],["$","h3",null,{"style":{"fontSize":"clamp(1.125rem, 2vw, 1.5rem)","fontWeight":700,"lineHeight":1.3,"marginBottom":"0.625rem","display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden","textOverflow":"ellipsis","whiteSpace":"nowrap"},"children":["$","$L3",null,{"href":"/reports/zvit-pro-diialnist-tsentru-zrostaiemo-razom-za-veresen-zhovten-2025","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Звіт про діяльність Центру «Зростаємо разом» за вересень–жовтень 2025"}]}],"$L12"]}]]}]}]]}]]}]}]
c:["$","section",null,{"className":"section","children":["$","div",null,{"className":"container","children":[["$","div",null,{"style":{"display":"flex","justifyContent":"space-between","alignItems":"flex-end","marginBottom":"2.5rem","flexWrap":"wrap","gap":"1rem"},"children":[["$","h2",null,{"className":"section-title","style":{"marginBottom":0},"children":"Найближчі події"}],["$","$L3",null,{"href":"/events","style":{"display":"flex","alignItems":"center","gap":"0.5rem","color":"var(--teal)","fontWeight":700,"textDecoration":"none","fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":["Всі події ",["$","$L4",null,{"iconNode":"$0:rsc:props:children:0:1:0:0:props:children:1:props:children:props:children:3:props:children:2:props:iconNode","className":"lucide-arrow-right","size":16}]]}]]}],["$","ul",null,{"style":{"listStyle":"none","display":"grid","gridTemplateColumns":"repeat(auto-fill, minmax(280px, 1fr))","gap":"1.5rem","alignItems":"stretch"},"children":[["$","li","4",{"style":{"display":"flex"},"children":["$","article",null,{"className":"card","style":{"display":"flex","flexDirection":"column","width":"100%","overflow":"hidden"},"children":[["$","$L3",null,{"href":"/events/trening-sila-buti---praktichni-zaniattia-dlia-mam","tabIndex":-1,"aria-hidden":"true","style":{"display":"block","position":"relative","flexShrink":0,"height":200,"overflow":"hidden","background":"var(--light-gray)"},"children":[["$","$L11",null,{"src":"https://api.mistosyly.org/media/images/events/photo_2026-07-06_18-18-11.jpg","alt":"Тренінг «Сила бути» - практичні заняття для мам","fill":true,"sizes":"(max-width: 640px) 100vw, 320px","priority":true,"style":{"objectFit":"cover","objectPosition":"center"}}],["$","div",null,{"style":{"position":"absolute","top":"1rem","left":"1rem","background":"var(--teal)","color":"#fff","padding":"0.5rem 0.75rem","textAlign":"center","minWidth":"52px"},"children":[["$","div",null,{"style":{"fontSize":"1.5rem","fontWeight":700,"lineHeight":1},"children":"1"}],["$","div",null,{"style":{"fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":"кві"}]]}]]}],["$","div",null,{"style":{"padding":"1.25rem","flex":1},"children":["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"lineHeight":1.3,"display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":["$","$L3",null,{"href":"/events/trening-sila-buti---praktichni-zaniattia-dlia-mam","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Тренінг «Сила бути» - практичні заняття для мам"}]}]}]]}]}],["$","li","3",{"style":{"display":"flex"},"children":["$","article",null,{"className":"card","style":{"display":"flex","flexDirection":"column","width":"100%","overflow":"hidden"},"children":[["$","$L3",null,{"href":"/events/tvorchii-maister-klas-dlia-ditei-vesniani-fantaziyi","tabIndex":-1,"aria-hidden":"true","style":{"display":"block","position":"relative","flexShrink":0,"height":200,"overflow":"hidden","background":"var(--light-gray)"},"children":[["$","$L11",null,{"src":"https://api.mistosyly.org/media/images/events/photo_2026-07-06_18-10-01_P0EPdra.jpg","alt":"Творчий майстер-клас для дітей «Весняні фантазії»","fill":true,"sizes":"(max-width: 640px) 100vw, 320px","priority":false,"style":{"objectFit":"cover","objectPosition":"center"}}],["$","div",null,{"style":{"position":"absolute","top":"1rem","left":"1rem","background":"var(--teal)","color":"#fff","padding":"0.5rem 0.75rem","textAlign":"center","minWidth":"52px"},"children":[["$","div",null,{"style":{"fontSize":"1.5rem","fontWeight":700,"lineHeight":1},"children":"2"}],["$","div",null,{"style":{"fontSize":"1rem","textTransform":"uppercase","letterSpacing":"0.05em"},"children":"бер"}]]}]]}],["$","div",null,{"style":{"padding":"1.25rem","flex":1},"children":["$","h3",null,{"style":{"fontSize":"1.125rem","fontWeight":700,"lineHeight":1.3,"display":"-webkit-box","WebkitLineClamp":2,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":["$","$L3",null,{"href":"/events/tvorchii-maister-klas-dlia-ditei-vesniani-fantaziyi","style":{"color":"var(--charcoal-dark)","textDecoration":"none"},"className":"home-link","children":"Творчий майстер-клас для дітей «Весняні фантазії»"}]}]}]]}]}]]}]]}]}]
d:["$","script","script-0",{"src":"/_next/static/chunks/0tkbf1af~7blx.js","async":true}]
e:["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]
12:["$","p",null,{"style":{"fontSize":"1rem","color":"var(--charcoal)","lineHeight":1.6,"display":"-webkit-box","WebkitLineClamp":3,"WebkitBoxOrient":"vertical","overflow":"hidden"},"children":"За перші два місяці роботи центру охоплено понад 120 дітей та 80 дорослих. Проведено групові та індивідуальні сесії психологічної підтримки, творчі майстер-класи та заняття з підготовки до школи."}]
15:null
