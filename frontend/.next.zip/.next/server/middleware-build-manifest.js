globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/jjS9nrPylH5BNIvF-Nnc4/_buildManifest.js",
    "static/jjS9nrPylH5BNIvF-Nnc4/_ssgManifest.js",
    "static/jjS9nrPylH5BNIvF-Nnc4/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/16xak96v1pi97.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/02g3221oh~3le.js",
    "static/chunks/turbopack-0lok79djmdk8_.js"
  ]
};
