(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,59632,e=>{"use strict";var t=e.i(43476),i=e.i(71645);e.s(["default",0,({html:e,className:r,style:l})=>{let o=(0,i.useRef)(null);(0,i.useEffect)(()=>{if(!o.current)return;let t=e||"";t=(t=t.replace(/<figure class="media">\s*<oembed url="([^"]+)"\s*\/?>\s*<\/oembed>\s*<\/figure>/gi,(e,t)=>s(t))).replace(/<oembed url="([^"]+)"\s*\/?>\s*<\/oembed>/gi,(e,t)=>s(t)),o.current.innerHTML=t,a()},[e]);let s=e=>{if(e.includes("youtube.com")||e.includes("youtu.be")){let t="";if(e.includes("youtu.be/")?t=e.split("youtu.be/")[1].split("?")[0]:e.includes("v=")?t=e.split("v=")[1].split("&")[0]:e.includes("embed/")&&(t=e.split("embed/")[1].split("?")[0]),t)return`
          <div class="video-container">
            <iframe
              src="https://www.youtube.com/embed/${t}"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
              loading="lazy"
            ></iframe>
          </div>
        `}if(e.includes("vimeo.com")){let t=e.split("/").pop()?.split("?")[0]||"";if(t)return`
          <div class="video-container">
            <iframe
              src="https://player.vimeo.com/video/${t}"
              frameborder="0"
              allow="autoplay; fullscreen; picture-in-picture"
              allowfullscreen
              loading="lazy"
            ></iframe>
          </div>
        `}return`<a href="${e}" target="_blank" rel="noopener noreferrer">${e}</a>`},a=()=>{if(document.getElementById("video-styles"))return;let e=document.createElement("style");e.id="video-styles",e.textContent=`
      .video-container {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        margin: 1.5rem 0;
        border-radius: 8px;
        overflow: hidden;
        background: #000;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      }
      .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
      }
    `,document.head.appendChild(e)};return(0,t.jsx)("div",{ref:o,className:r,style:l})}])}]);